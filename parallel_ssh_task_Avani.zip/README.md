### parallel SSH demo (without packages)
there can be 2 approaches here :

first is just use 
pip install parallel-ssh
python main_pssh.py
which is python's lib for this usecase itself

second is manually using threading which i have implemented in main.py and it is tested and working

# what this does in short??
Runs the same file processing command on multiple servers ips in parallel using SSH.

# files i included
-process_file.py -> dummy processing script
-main.py ->runs SSH commands in parallel
-ips.txt -> list of server IPs

-main_pssh.py ->this is the parallel-ssh implementation

# Setup Steps

1. making sure ssh works coz this wont work without ssh ,try this command first in powershell:
   ssh username@127.0.0.1

2. if ssh not working download from github https://github.com/PowerShell/Win32-OpenSSH/releases

use this command strictly on the admin powershell coz it needs permissions:
"""
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0
Start-Service sshd
Set-Service -Name sshd -StartupType Automatic
"""

3. once ssh works try this command on any powershell

ssh username@127.0.0.1
(replace username with your real computer directory username ,my case was avani)

4. then you can run this script in the folder terminal:
   python main.py

# expected Output
servers will run the script at the same time and we can confirm the time is divided by 3 processes here as there are 3 mentioned ips in ips.txt.

the output i got looks like this :

PS Z:\parallel_ssh_demo> python main.py
Running on 127.0.0.1
Running on 127.0.0.1
Running on 127.0.0.1

Processing started...
Processing started...
Processing started...
Processing done!
Processing done!
Processing done!
All servers done!
Total time: 5.501683712005615
PS Z:\NewDownloads\parallel_ssh_demo>


5+5+5 tasks were divided by 3 servers with help of threading and it took 5.501683712005615 seconds to complete the task ,hence showcasing the threading and parallelism

# difficulties i faced
majorly wrt ssh because it's setup took a long time as it required many permissions before ,so i had to download it from github and then extract it 

# references i used 
#reference - 
ssh -- https://www.geeksforgeeks.org/python/automated-ssh-bot-in-python/
threading -- https://docs.python.org/3/library/threading.html
time -- https://docs.python.org/3/library/time.html
os -- https://docs.python.org/3/library/os.html
open -- https://docs.python.org/3/library/functions.html#open

https://stackoverflow.com/questions/1185855/parallel-ssh-in-python

https://stackoverflow.com/questions/1185855/parallel-ssh-in-python

https://stackoverflow.com/questions/1185855/parallel-ssh-in-python

https://discuss.python.org/t/running-ssh-in-parallel/7404


# main differences in the aprroaches
instead of manually spawning threads and shelling out to ssh, ParallelSSHClient handles all the parallelism and SSH connections internally using its own async engine. Same result, so easy work without any additional overhead.