import time

print("Processing started...")
time.sleep(5)
print("Processing done!")
