import os
import threading
import time

user = "Aryan"
command = "cd Z:\\NewDownloads\\parallel_ssh_demo && python process_file.py input.txt"

# Read IPs
with open("ips.txt", "r") as f:
    servers = [line.strip() for line in f if line.strip()]

def run(ip):
    print(f"Running on {ip}")
    os.system(f"ssh {user}@{ip} {command}")

threads = []

start = time.time()

for ip in servers:
    t = threading.Thread(target=run, args=(ip,))
    t.start()
    threads.append(t)

for t in threads:
    t.join()

end = time.time()

print("All servers done!")
print("Total time:", end - start)
